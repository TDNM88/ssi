// Trading constants
export const DI = "up"
export const nae = "down"

// Other constants
export const MINIMUM_BET = 10000
export const MINIMUM_DEPOSIT = 50000
export const MINIMUM_WITHDRAW = 100000
